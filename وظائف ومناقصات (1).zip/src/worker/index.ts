import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { JobSchema, TenderSchema } from "@/shared/types";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";

const app = new Hono<{ Bindings: Env }>();

// Authentication endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Admin statistics endpoint
app.get("/api/admin/stats", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  // Check if user is admin (you can customize this logic)
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  const [jobsCount, tendersCount, activeJobsCount, activeTendersCount] = await Promise.all([
    c.env.DB.prepare("SELECT COUNT(*) as count FROM jobs").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM tenders").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM jobs WHERE is_active = 1").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM tenders WHERE is_active = 1").first(),
  ]);

  return c.json({
    totalJobs: jobsCount?.count || 0,
    totalTenders: tendersCount?.count || 0,
    activeJobs: activeJobsCount?.count || 0,
    activeTenders: activeTendersCount?.count || 0,
  });
});

// Jobs API - Show only approved jobs to public
app.get("/api/jobs", async (c) => {
  const jobs = await c.env.DB.prepare("SELECT * FROM jobs WHERE is_active = 1 AND is_approved = 1 ORDER BY created_at DESC").all();
  return c.json(jobs.results);
});

app.get("/api/jobs/:id", async (c) => {
  const id = c.req.param("id");
  const job = await c.env.DB.prepare("SELECT * FROM jobs WHERE id = ? AND is_active = 1 AND is_approved = 1").bind(id).first();
  if (!job) {
    return c.json({ error: "الوظيفة غير موجودة" }, 404);
  }
  return c.json(job);
});

app.post("/api/jobs", authMiddleware, zValidator("json", JobSchema), async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const jobData = c.req.valid("json");
  const now = new Date().toISOString();
  
  const result = await c.env.DB.prepare(`
    INSERT INTO jobs (title, company, location, salary_range, job_type, description, requirements, contact_email, contact_phone, expires_at, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    jobData.title,
    jobData.company,
    jobData.location || null,
    jobData.salary_range || null,
    jobData.job_type || null,
    jobData.description,
    jobData.requirements || null,
    jobData.contact_email || null,
    jobData.contact_phone || null,
    jobData.expires_at || null,
    user.id,
    now,
    now
  ).run();

  return c.json({ id: result.meta.last_row_id, message: "تم إنشاء الوظيفة بنجاح وهي قيد المراجعة" });
});

// Tenders API - Show only approved tenders to public
app.get("/api/tenders", async (c) => {
  const tenders = await c.env.DB.prepare("SELECT * FROM tenders WHERE is_active = 1 AND is_approved = 1 ORDER BY created_at DESC").all();
  return c.json(tenders.results);
});

app.get("/api/tenders/:id", async (c) => {
  const id = c.req.param("id");
  const tender = await c.env.DB.prepare("SELECT * FROM tenders WHERE id = ? AND is_approved = 1 AND is_active = 1").bind(id).first();
  if (!tender) {
    return c.json({ error: "المناقصة غير موجودة" }, 404);
  }
  return c.json(tender);
});

app.post("/api/tenders", authMiddleware, zValidator("json", TenderSchema), async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const tenderData = c.req.valid("json");
  const now = new Date().toISOString();
  
  const result = await c.env.DB.prepare(`
    INSERT INTO tenders (title, organization, reference_number, category, description, requirements, budget_range, submission_deadline, contact_email, contact_phone, tender_documents_url, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    tenderData.title,
    tenderData.organization,
    tenderData.reference_number || null,
    tenderData.category || null,
    tenderData.description,
    tenderData.requirements || null,
    tenderData.budget_range || null,
    tenderData.submission_deadline || null,
    tenderData.contact_email || null,
    tenderData.contact_phone || null,
    tenderData.tender_documents_url || null,
    user.id,
    now,
    now
  ).run();

  return c.json({ id: result.meta.last_row_id, message: "تم إنشاء المناقصة بنجاح وهي قيد المراجعة" });
});

// Admin approval endpoints
app.get("/api/admin/pending-jobs", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  const jobs = await c.env.DB.prepare("SELECT * FROM jobs WHERE is_approved = 0 AND is_active = 1 ORDER BY created_at DESC").all();
  return c.json(jobs.results);
});

app.get("/api/admin/pending-tenders", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  const tenders = await c.env.DB.prepare("SELECT * FROM tenders WHERE is_approved = 0 AND is_active = 1 ORDER BY created_at DESC").all();
  return c.json(tenders.results);
});

app.post("/api/admin/approve-job/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  const now = new Date().toISOString();
  
  await c.env.DB.prepare(`
    UPDATE jobs 
    SET is_approved = 1, approved_by = ?, approved_at = ?, updated_at = ?
    WHERE id = ?
  `).bind(user.id, now, now, id).run();

  return c.json({ message: "تم الموافقة على الوظيفة" });
});

app.post("/api/admin/approve-tender/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  const now = new Date().toISOString();
  
  await c.env.DB.prepare(`
    UPDATE tenders 
    SET is_approved = 1, approved_by = ?, approved_at = ?, updated_at = ?
    WHERE id = ?
  `).bind(user.id, now, now, id).run();

  return c.json({ message: "تم الموافقة على المناقصة" });
});

app.delete("/api/admin/reject-job/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  await c.env.DB.prepare("UPDATE jobs SET is_active = 0 WHERE id = ?").bind(id).run();

  return c.json({ message: "تم رفض الوظيفة" });
});

app.delete("/api/admin/reject-tender/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  await c.env.DB.prepare("UPDATE tenders SET is_active = 0 WHERE id = ?").bind(id).run();

  return c.json({ message: "تم رفض المناقصة" });
});

// Applications API with AI matching
app.post("/api/applications", authMiddleware, zValidator("json", z.object({
  job_id: z.string(),
  applicant_name: z.string(),
  applicant_email: z.string().email(),
  applicant_phone: z.string().optional(),
  cover_letter: z.string().optional(),
  resume_url: z.string().optional(),
})), async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const applicationData = c.req.valid("json");
  const now = new Date().toISOString();
  
  // Get job details for AI matching
  const job = await c.env.DB.prepare("SELECT * FROM jobs WHERE id = ?").bind(applicationData.job_id).first();
  
  if (!job) {
    return c.json({ error: "الوظيفة غير موجودة" }, 404);
  }

  let aiMatchScore = 0;
  let aiAnalysis = "لم يتم تحليل السيرة الذاتية بعد";

  // AI Resume Analysis using OpenAI
  if (c.env.OPENAI_API_KEY && applicationData.cover_letter) {
    try {
      const prompt = `
        تحليل مطابقة السيرة الذاتية مع الوظيفة:
        
        الوظيفة:
        المنصب: ${job.title}
        الشركة: ${job.company}
        الوصف: ${job.description}
        المتطلبات: ${job.requirements || 'غير محددة'}
        
        معلومات المتقدم:
        الاسم: ${applicationData.applicant_name}
        خطاب التغطية: ${applicationData.cover_letter}
        
        يرجى تقييم مدى مطابقة المتقدم للوظيفة من 1-100 وإعطاء تحليل مختصر بالعربية.
        الرد يجب أن يكون بتنسيق JSON:
        {"score": رقم_النقاط, "analysis": "التحليل_بالعربية"}
      `;

      const response = await (globalThis as any).fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${c.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'system',
              content: 'أنت خبير في الموارد البشرية متخصص في تقييم السير الذاتية وتحليل مطابقتها للوظائف. أجب دائماً بالعربية.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 500,
        }),
      });

      if (response.ok) {
        const aiResponse = await response.json() as any;
        const content = aiResponse.choices[0].message.content;
        
        try {
          const parsedContent = JSON.parse(content);
          aiMatchScore = parsedContent.score || 0;
          aiAnalysis = parsedContent.analysis || "تم تحليل السيرة الذاتية بنجاح";
        } catch {
          // If JSON parsing fails, extract score and analysis manually
          const scoreMatch = content.match(/(\d+)/);
          aiMatchScore = scoreMatch ? parseInt(scoreMatch[1]) : 50;
          aiAnalysis = content.replace(/[{}"]|score:|analysis:/g, '').trim() || "تم تحليل الطلب";
        }
      }
    } catch (error) {
      // Error calling OpenAI
      aiMatchScore = 50; // Default score
      aiAnalysis = "حدث خطأ في تحليل السيرة الذاتية";
    }
  }
  
  const result = await c.env.DB.prepare(`
    INSERT INTO applications (job_id, applicant_name, applicant_email, applicant_phone, resume_url, cover_letter, ai_match_score, ai_analysis, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    applicationData.job_id,
    applicationData.applicant_name,
    applicationData.applicant_email,
    applicationData.applicant_phone || null,
    applicationData.resume_url || null,
    applicationData.cover_letter || null,
    aiMatchScore,
    aiAnalysis,
    now,
    now
  ).run();

  return c.json({ 
    id: result.meta.last_row_id, 
    message: "تم إرسال طلبك بنجاح وسيتم مراجعته",
    ai_match_score: aiMatchScore
  });
});

// Proposals API
app.post("/api/proposals", authMiddleware, zValidator("json", z.object({
  tender_id: z.string(),
  company_name: z.string(),
  contact_email: z.string().email(),
  contact_phone: z.string().optional(),
  proposal_url: z.string().optional(),
})), async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const proposalData = c.req.valid("json");
  const now = new Date().toISOString();
  
  const result = await c.env.DB.prepare(`
    INSERT INTO proposals (tender_id, company_name, contact_email, contact_phone, proposal_url, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).bind(
    proposalData.tender_id,
    proposalData.company_name,
    proposalData.contact_email,
    proposalData.contact_phone || null,
    proposalData.proposal_url || null,
    now,
    now
  ).run();

  return c.json({ 
    id: result.meta.last_row_id, 
    message: "تم إرسال عرضك بنجاح وسيتم مراجعته" 
  });
});

// Admin applications management
app.get("/api/admin/applications/:jobId", authMiddleware, async (c) => {
  const user = c.get("user");
  const jobId = c.req.param("jobId");
  
  if (!user) {
    return c.json({ error: "غير مصرح" }, 401);
  }
  
  const isAdmin = user.email === "admin@example.com" || user.email.endsWith("@getmocha.com");
  
  if (!isAdmin) {
    return c.json({ error: "غير مصرح لك بالوصول" }, 403);
  }

  const applications = await c.env.DB.prepare(`
    SELECT a.*, j.title as job_title, j.company 
    FROM applications a 
    JOIN jobs j ON a.job_id = j.id 
    WHERE a.job_id = ? 
    ORDER BY a.ai_match_score DESC, a.created_at DESC
  `).bind(jobId).all();
  
  return c.json(applications.results);
});

export default app;
