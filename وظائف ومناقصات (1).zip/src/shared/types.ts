import z from "zod";

export const JobSchema = z.object({
  id: z.number().optional(),
  title: z.string().min(1, "العنوان مطلوب"),
  company: z.string().min(1, "اسم الشركة مطلوب"),
  location: z.string().optional(),
  salary_range: z.string().optional(),
  job_type: z.string().optional(),
  description: z.string().min(1, "الوصف مطلوب"),
  requirements: z.string().optional(),
  contact_email: z.string().email("البريد الإلكتروني غير صحيح").optional(),
  contact_phone: z.string().optional(),
  is_active: z.boolean().default(true),
  expires_at: z.string().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export const TenderSchema = z.object({
  id: z.number().optional(),
  title: z.string().min(1, "العنوان مطلوب"),
  organization: z.string().min(1, "اسم المؤسسة مطلوب"),
  reference_number: z.string().optional(),
  category: z.string().optional(),
  description: z.string().min(1, "الوصف مطلوب"),
  requirements: z.string().optional(),
  budget_range: z.string().optional(),
  submission_deadline: z.string().optional(),
  contact_email: z.string().email("البريد الإلكتروني غير صحيح").optional(),
  contact_phone: z.string().optional(),
  tender_documents_url: z.string().optional(),
  is_active: z.boolean().default(true),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type JobType = z.infer<typeof JobSchema>;
export type TenderType = z.infer<typeof TenderSchema>;
