
DROP TABLE applications;
DROP TABLE proposals;
