
ALTER TABLE jobs DROP COLUMN created_by;
ALTER TABLE tenders DROP COLUMN created_by;
