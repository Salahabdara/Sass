
ALTER TABLE jobs DROP COLUMN is_approved;
ALTER TABLE jobs DROP COLUMN approved_by;
ALTER TABLE jobs DROP COLUMN approved_at;

ALTER TABLE tenders DROP COLUMN is_approved;
ALTER TABLE tenders DROP COLUMN approved_by;
ALTER TABLE tenders DROP COLUMN approved_at;
