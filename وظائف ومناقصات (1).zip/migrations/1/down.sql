
DROP TABLE jobs;
