
ALTER TABLE jobs ADD COLUMN created_by TEXT;
ALTER TABLE tenders ADD COLUMN created_by TEXT;
