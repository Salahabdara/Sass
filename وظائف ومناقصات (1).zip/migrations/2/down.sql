
DROP TABLE tenders;
